# Taxi Local PWA v2 — piloto multi-dispositivo

PWA para Elda y Petrer, sin pagos ni suscripciones. Esta entrega incorpora el cliente Supabase, autenticación por email/contraseña, perfiles cliente/conductor, solicitudes remotas, escucha Realtime y funciones SQL transaccionales para aceptar/completar/cancelar viajes.

## Lo que ya está implementado en el código
- Registro e inicio de sesión por email/contraseña.
- Al registrarse, el usuario solicita perfil de cliente o conductor; todo conductor comienza **sin verificar**.
- Alta de solicitudes de viaje en PostgreSQL con localidad, recogida, destino, pasajeros, teléfono, notas, GPS opcional y reserva.
- Panel de conductor aprobado, disponibilidad y escucha de cambios en tiempo real.
- Aceptación atómica en servidor: dos conductores no pueden reclamar el mismo viaje.
- Cancelación por cliente y finalización por conductor, validadas en funciones SQL.
- PWA adaptable, manifiesto e instalación desde HTTPS.

## Aún NO desplegado
No se ha creado un proyecto Supabase ni un alojamiento web, porque requieren acceso/consentimiento del propietario. Hasta introducir credenciales y desplegar, la app se mantiene deliberadamente en modo seguro y no simula viajes multi-dispositivo. No está lista para operar servicios comerciales.

## Activación del backend
1. Crea un proyecto en Supabase.
2. En **SQL Editor**, ejecuta el archivo `supabase/schema.sql` en un proyecto nuevo.
3. En **Authentication → Providers**, activa Email. Para una prueba controlada puedes decidir si exigir confirmación de correo; recomendamos mantenerla en el piloto.
4. Copia la Project URL y la publishable key (o anon key heredada) desde la configuración API del proyecto.
5. Abre `config.js` y completa `supabaseUrl` y `supabaseAnonKey`. En el navegador solo debe usarse la clave pública. **Nunca** uses `service_role` ni secretos de servidor en `config.js`.
6. Publica la carpeta completa por HTTPS en un hosting estático. `index.html`, `app.js`, `config.js`, `styles.css`, `manifest.webmanifest`, `icon.svg` y `sw.js` deben permanecer juntos.
7. Crea dos cuentas de prueba (cliente y conductor). El conductor no puede recibir viajes hasta ser verificado por un administrador.

## Aprobar al primer administrador / conductores
La tabla protege `role` y `is_verified` contra cambios de usuarios normales. Para designar inicialmente un administrador, hazlo solo desde SQL Editor del proyecto propio y revisa el UUID del usuario correcto:

```sql
-- Sustituye el UUID por el usuario que tú controlas y has confirmado.
-- Acción privilegiada: ejecutar solo desde SQL Editor del propietario.
alter table public.profiles disable trigger protect_profile_privileges_trigger;
update public.profiles set role='admin' where id='UUID-DEL-ADMINISTRADOR';
alter table public.profiles enable trigger protect_profile_privileges_trigger;
```

Después, el administrador puede aprobar un conductor con la función `set_driver_verification(UUID_DEL_CONDUCTOR, true)` desde un cliente autenticado que tenga ese perfil admin. Para el piloto, no aceptes documentos de identidad por chat ni guardes más información de la necesaria.

## Prueba mínima antes de invitar taxistas
1. Crear cuenta cliente; iniciar sesión y enviar un viaje ficticio en Elda.
2. Aprobar una cuenta de conductor de prueba y activar su disponibilidad en Elda.
3. Verificar que la solicitud aparece en el segundo dispositivo sin recargar la página.
4. Aceptar el viaje desde el conductor; comprobar que el estado cambia en el cliente.
5. Probar cancelación, finalización, reserva futura, permiso GPS denegado, conexión perdida y dos conductores intentando aceptar a la vez.
6. Confirmar que un conductor de Petrer no ve solicitudes pendientes de Elda si no está asignado.

## Seguridad y límites de este piloto
- La PWA usa Supabase Auth y políticas RLS; aun así, este SQL necesita revisión independiente antes de datos reales.
- La política de lectura de solicitudes pendientes permite a conductores verificados y disponibles de esa localidad ver algunos datos de la solicitud, incluido teléfono. Para una operación pública, se recomienda separar los datos de contacto en una vista/función que los revele únicamente al conductor asignado.
- El navegador no implementa todavía notificaciones push fiables en segundo plano, seguimiento continuo de conductor, cálculo de rutas, pagos, verificación documental ni panel administrativo completo.
- No se incluyen contratos, política de privacidad, retención/borrado automatizado, evaluación RGPD ni comprobaciones de requisitos municipales de taxi.
- No usar para viajes comerciales con pasajeros hasta realizar auditoría de seguridad, pruebas de campo y revisión legal/operativa.
