-- Taxi Local PWA v2 — ejecutar en Supabase SQL Editor en un proyecto NUEVO.
-- Piloto sin pagos. Revisar y probar con datos ficticios antes de publicar.
create extension if not exists pgcrypto;
do $$ begin create type public.app_role as enum ('rider','driver','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type public.ride_status as enum ('pending','accepted','cancelled','completed','no_driver'); exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 role public.app_role not null default 'rider',
 full_name text not null check (char_length(full_name) between 1 and 100),
 phone text not null check (char_length(phone) between 3 and 30),
 town text not null check (town in ('Elda','Petrer')),
 is_verified boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.driver_presence (
 driver_id uuid primary key references public.profiles(id) on delete cascade,
 town text not null check (town in ('Elda','Petrer')),
 is_available boolean not null default false,
 last_seen_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.rides (
 id uuid primary key default gen_random_uuid(),
 rider_id uuid not null references public.profiles(id),
 driver_id uuid references public.profiles(id),
 town text not null check (town in ('Elda','Petrer')),
 pickup_address text not null check (char_length(pickup_address) between 2 and 160),
 destination_address text,
 pickup_lat double precision check (pickup_lat is null or pickup_lat between -90 and 90),
 pickup_lng double precision check (pickup_lng is null or pickup_lng between -180 and 180),
 passengers integer not null default 1 check (passengers between 1 and 8),
 rider_phone text not null,
 notes text check (notes is null or char_length(notes) <= 300),
 status public.ride_status not null default 'pending',
 scheduled_for timestamptz,
 accepted_at timestamptz, completed_at timestamptz, cancelled_at timestamptz,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists rides_town_status_created_idx on public.rides(town,status,created_at desc);
create index if not exists rides_rider_created_idx on public.rides(rider_id,created_at desc);
create index if not exists rides_driver_status_idx on public.rides(driver_id,status);

-- Perfil generado por Auth. El rol conductor es solicitado, pero siempre queda sin verificar.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
declare requested text; begin
 requested := coalesce(new.raw_user_meta_data->>'requested_role','rider');
 insert into public.profiles(id,role,full_name,phone,town,is_verified)
 values(new.id, case when requested='driver' then 'driver'::public.app_role else 'rider'::public.app_role end,
 coalesce(nullif(trim(new.raw_user_meta_data->>'full_name'),''),'Usuario'),
 coalesce(nullif(trim(new.raw_user_meta_data->>'phone'),''),''),
 case when new.raw_user_meta_data->>'town' in ('Elda','Petrer') then new.raw_user_meta_data->>'town' else 'Elda' end, false);
 return new; end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Evita que el usuario se otorgue privilegios cambiando su rol o verificación.
create or replace function public.protect_profile_privileges() returns trigger language plpgsql set search_path=public as $$
begin
 if new.role is distinct from old.role or new.is_verified is distinct from old.is_verified then
   raise exception 'El rol y la verificación solo los puede cambiar un administrador autorizado';
 end if;
 return new;
end $$;
drop trigger if exists protect_profile_privileges_trigger on public.profiles;
create trigger protect_profile_privileges_trigger before update on public.profiles for each row execute procedure public.protect_profile_privileges();

alter table public.profiles enable row level security;
alter table public.driver_presence enable row level security;
alter table public.rides enable row level security;
revoke all on public.profiles,public.driver_presence,public.rides from anon;
grant select, update on public.profiles to authenticated;
grant select, insert, update on public.driver_presence to authenticated;
grant select, insert on public.rides to authenticated;

drop policy if exists profiles_select_self on public.profiles;
create policy profiles_select_self on public.profiles for select to authenticated using(id=auth.uid());
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
drop policy if exists presence_self_select on public.driver_presence;
create policy presence_self_select on public.driver_presence for select to authenticated using(driver_id=auth.uid());
drop policy if exists presence_self_insert on public.driver_presence;
create policy presence_self_insert on public.driver_presence for insert to authenticated with check(driver_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='driver' and p.is_verified));
drop policy if exists presence_self_update on public.driver_presence;
create policy presence_self_update on public.driver_presence for update to authenticated using(driver_id=auth.uid()) with check(driver_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='driver' and p.is_verified));
drop policy if exists ride_insert_self on public.rides;
create policy ride_insert_self on public.rides for insert to authenticated with check(rider_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='rider') and driver_id is null and status='pending');
drop policy if exists ride_select_rider_or_driver on public.rides;
create policy ride_select_rider_or_driver on public.rides for select to authenticated using(
 rider_id=auth.uid() or driver_id=auth.uid() or
 (status='pending' and exists(select 1 from public.profiles p join public.driver_presence dp on dp.driver_id=p.id where p.id=auth.uid() and p.role='driver' and p.is_verified and dp.is_available and dp.town=rides.town))
);

-- Cambios de estado transaccionales: evita que dos conductores acepten el mismo viaje.
create or replace function public.accept_ride(p_ride_id uuid) returns void language plpgsql security definer set search_path=public as $$
declare p public.profiles%rowtype; r public.rides%rowtype; begin
 select * into p from public.profiles where id=auth.uid();
 if p.id is null or p.role<>'driver' or not p.is_verified then raise exception 'Conductor no autorizado'; end if;
 if not exists(select 1 from public.driver_presence dp where dp.driver_id=auth.uid() and dp.is_available and dp.town=p.town) then raise exception 'Activa tu disponibilidad'; end if;
 update public.rides set driver_id=auth.uid(),status='accepted',accepted_at=now(),updated_at=now()
 where id=p_ride_id and status='pending' and town=p.town and driver_id is null;
 if not found then raise exception 'El viaje ya no está disponible'; end if;
end $$;
create or replace function public.complete_ride(p_ride_id uuid) returns void language plpgsql security definer set search_path=public as $$
begin update public.rides set status='completed',completed_at=now(),updated_at=now() where id=p_ride_id and driver_id=auth.uid() and status='accepted'; if not found then raise exception 'No puedes completar este viaje'; end if; end $$;
create or replace function public.cancel_ride(p_ride_id uuid) returns void language plpgsql security definer set search_path=public as $$
begin update public.rides set status='cancelled',cancelled_at=now(),updated_at=now() where id=p_ride_id and rider_id=auth.uid() and status='pending'; if not found then raise exception 'No puedes cancelar este viaje'; end if; end $$;
revoke all on function public.accept_ride(uuid),public.complete_ride(uuid),public.cancel_ride(uuid) from public,anon;
grant execute on function public.accept_ride(uuid),public.complete_ride(uuid),public.cancel_ride(uuid) to authenticated;

-- Habilitar Realtime para que la interfaz reciba cambios de solicitudes.
alter table public.rides replica identity full;
do $$ begin alter publication supabase_realtime add table public.rides; exception when duplicate_object then null; when undefined_object then null; end $$;

-- Un administrador existente puede aprobar conductores mediante esta función.
create or replace function public.set_driver_verification(p_driver_id uuid, p_verified boolean) returns void language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from public.profiles where id=auth.uid() and role='admin') then raise exception 'Solo un administrador puede verificar conductores'; end if;
 update public.profiles set is_verified=p_verified where id=p_driver_id and role='driver';
 if not found then raise exception 'No se encontró la cuenta de conductor'; end if;
end $$;
revoke all on function public.set_driver_verification(uuid,boolean) from public,anon;
grant execute on function public.set_driver_verification(uuid,boolean) to authenticated;

-- IMPORTANTE: la verificación de conductores debe hacerla un administrador desde un canal seguro.
-- No habilitar acceso público ni usar datos reales hasta revisar RLS, exposición del teléfono,
-- confirmación de email, límites antiabuso, RGPD y pruebas de seguridad.
