import 'package:flutter/material.dart';

void main() => runApp(const TaxiLocalApp());

const taxiYellow = Color(0xFFFFD21F);
const ink = Color(0xFF171717);

class TaxiLocalApp extends StatelessWidget {
  const TaxiLocalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Taxi Local',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: taxiYellow),
        scaffoldBackgroundColor: const Color(0xFFF7F7F5),
        useMaterial3: true,
        textTheme: const TextTheme(
          headlineMedium: TextStyle(fontWeight: FontWeight.w800, color: ink),
          titleLarge: TextStyle(fontWeight: FontWeight.w800, color: ink),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: taxiYellow,
            foregroundColor: ink,
            minimumSize: const Size.fromHeight(58),
            textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: ink,
        foregroundColor: Colors.white,
        title: const Text('TAXI LOCAL', style: TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 16),
            const Text('Tu taxi, fácil y cerca.', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Pide un taxi en tu pueblo con unos pocos toques.', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 26),
            SizedBox(
              height: 150,
              child: ElevatedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RequestRideScreen())),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.local_taxi, size: 42),
                    SizedBox(height: 8),
                    Text('PEDIR TAXI', style: TextStyle(fontSize: 28)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(58)),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverScreen())),
              icon: const Icon(Icons.drive_eta),
              label: const Text('SOY CONDUCTOR', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            ),
            const SizedBox(height: 22),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('Versión inicial de diseño. Aún no envía viajes reales ni comparte tu ubicación.'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RequestRideScreen extends StatefulWidget {
  const RequestRideScreen({super.key});

  @override
  State<RequestRideScreen> createState() => _RequestRideScreenState();
}

class _RequestRideScreenState extends State<RequestRideScreen> {
  final town = TextEditingController();
  final address = TextEditingController();
  final phone = TextEditingController();
  final details = TextEditingController();
  bool locationRequested = false;
  bool submitted = false;

  @override
  void dispose() {
    town.dispose();
    address.dispose();
    phone.dispose();
    details.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pedir taxi')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('¿Dónde te recogemos?', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('Puedes compartir tu ubicación o escribir la dirección.'),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () {
              setState(() => locationRequested = true);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('La ubicación GPS se conectará en la siguiente fase.')),
              );
            },
            icon: const Icon(Icons.my_location),
            label: const Text('USAR MI UBICACIÓN'),
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          ),
          if (locationRequested)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('Pendiente de integrar el permiso GPS del dispositivo.'),
            ),
          const SizedBox(height: 12),
          _field(town, 'Pueblo', 'Ej. Elda'),
          _field(address, 'Dirección de recogida', 'Calle, número o punto conocido'),
          _field(phone, 'Teléfono', 'Número de contacto', keyboard: TextInputType.phone),
          _field(details, 'Detalles (opcional)', 'Maletas, accesibilidad…', maxLines: 2),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              if (town.text.trim().isEmpty || address.text.trim().isEmpty || phone.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Completa pueblo, dirección y teléfono.')));
                return;
              }
              setState(() => submitted = true);
            },
            child: const Text('ENVIAR SOLICITUD'),
          ),
          if (submitted)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('Formulario validado en modo demo. La solicitud aún no se ha enviado a un conductor.'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, String hint,
      {TextInputType keyboard = TextInputType.text, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 13),
      child: TextField(
        controller: controller,
        keyboardType: keyboard,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
        ),
      ),
    );
  }
}

class DriverScreen extends StatefulWidget {
  const DriverScreen({super.key});

  @override
  State<DriverScreen> createState() => _DriverScreenState();
}

class _DriverScreenState extends State<DriverScreen> {
  int tab = 0;
  bool available = false;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const _InfoPanel(
        icon: Icons.inbox_outlined,
        title: 'Solicitudes',
        body: 'Aquí aparecerán las solicitudes del pueblo asignado. La asignación real se hará desde el servidor.',
      ),
      const _InfoPanel(
        icon: Icons.calendar_month,
        title: 'Mi agenda',
        body: 'Aquí podrás consultar y gestionar tus reservas futuras.',
      ),
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const _InfoPanel(
            icon: Icons.campaign_outlined,
            title: 'Anúnciame',
            body: 'Activa tu disponibilidad para que los usuarios de tu pueblo reciban un aviso si aceptaron las notificaciones.',
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: () => setState(() => available = !available),
            child: Text(available ? 'DESACTIVAR DISPONIBILIDAD' : 'ACTIVAR DISPONIBILIDAD'),
          ),
          Text(available ? 'Estado de demostración: disponible' : 'Estado de demostración: no disponible'),
        ],
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Zona de conductores')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Panel del conductor', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('Solicitudes'), icon: Icon(Icons.inbox)),
              ButtonSegment(value: 1, label: Text('Agenda'), icon: Icon(Icons.calendar_month)),
              ButtonSegment(value: 2, label: Text('Anúnciame'), icon: Icon(Icons.campaign)),
            ],
            selected: {tab},
            onSelectionChanged: (value) => setState(() => tab = value.first),
          ),
          const SizedBox(height: 16),
          pages[tab],
          const SizedBox(height: 16),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('La verificación del conductor, la prueba gratuita y el estado de pago deben comprobarse en el servidor, no solo en esta pantalla.'),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoPanel extends StatelessWidget {
  const _InfoPanel({required this.icon, required this.title, required this.body});
  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 34),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(body, style: const TextStyle(fontSize: 17)),
          ],
        ),
      ),
    );
  }
}
