# Diseño funcional de Taxi Local v2

## Flujo de solicitud
1. El cliente inicia sesión y concede permiso de ubicación solo cuando pulsa «Pedir taxi».
2. La app envía pueblo, coordenadas, dirección y teléfono al servidor autenticado.
3. El servidor valida la solicitud y busca conductores verificados, disponibles, con ubicación reciente y suscripción vigente o dentro de la prueba.
4. Se ofrece el viaje al candidato más cercano por distancia en línea recta. La primera versión puede calcular por GPS; el tiempo real de llegada requerirá una API de rutas.
5. El conductor recibe un push y dispone de un tiempo limitado para aceptar.
6. Si rechaza o no responde, el servidor ofrece el viaje al siguiente candidato. Si no hay conductores, informa al cliente y ofrece llamar o reintentar.
7. Una vez aceptado, se comparten los datos de contacto necesarios y se muestra el estado del viaje.

## Prueba y mensualidad
- Guardar `trial_started_at` y `trial_ends_at` en el servidor.
- El servidor determina si el conductor puede recibir solicitudes.
- No confiar en una fecha almacenada únicamente en el móvil.
- El proveedor de pagos debe enviar webhooks verificados al backend.
- Antes de elegir Stripe, revisar las reglas vigentes de Google Play y Apple para suscripciones a este tipo de servicio; puede ser necesario usar los sistemas de compra de las tiendas según cómo se clasifique el servicio y cómo se venda.

## Ubicación y privacidad
- Pedir permiso solo cuando sea necesario y explicar el motivo.
- Compartir ubicación del conductor solo cuando esté conectado/disponible, con controles visibles.
- No mantener seguimiento continuo cuando el conductor esté desconectado.
- Definir conservación y borrado de coordenadas, teléfonos y viajes.
- No mostrar a todos los conductores el teléfono o ubicación exacta de un cliente; solo al conductor al que se ofrece/acepta el viaje y solo cuando sea necesario.
- Documentar tratamiento RGPD, base jurídica, derechos, política de privacidad y contactos.

## Funciones que dejaría fuera de la primera versión
- Tarifas y cobros al pasajero dentro de la app.
- Seguimiento en directo de un vehículo durante todo el viaje.
- Chat interno.
- Valoraciones públicas.
- Cobertura de varias provincias.
- Promociones avanzadas y anuncios segmentados.
