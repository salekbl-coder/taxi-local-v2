-- Taxi Local v2 — esquema inicial. Revisar con un profesional antes de producción.
create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('rider', 'driver', 'admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.ride_status as enum ('pending', 'offered', 'accepted', 'cancelled', 'completed', 'no_driver');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null default 'rider',
  full_name text not null,
  phone text,
  town text not null,
  is_verified boolean not null default false,
  trial_started_at timestamptz,
  trial_ends_at timestamptz,
  subscription_status text not null default 'trialing'
    check (subscription_status in ('trialing','active','past_due','cancelled','expired')),
  created_at timestamptz not null default now()
);

create table if not exists public.driver_presence (
  driver_id uuid primary key references public.profiles(id) on delete cascade,
  town text not null,
  is_available boolean not null default false,
  latitude double precision,
  longitude double precision,
  last_location_at timestamptz,
  last_seen_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (latitude is null or latitude between -90 and 90),
  check (longitude is null or longitude between -180 and 180)
);

create table if not exists public.rides (
  id uuid primary key default gen_random_uuid(),
  rider_id uuid not null references public.profiles(id),
  driver_id uuid references public.profiles(id),
  town text not null,
  pickup_address text not null,
  pickup_lat double precision,
  pickup_lng double precision,
  rider_phone text not null,
  notes text,
  status public.ride_status not null default 'pending',
  offered_at timestamptz,
  accepted_at timestamptz,
  scheduled_for timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.driver_announcements (
  driver_id uuid primary key references public.profiles(id) on delete cascade,
  town text not null,
  is_active boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists public.device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  token text not null unique,
  platform text not null check (platform in ('android','ios')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists driver_presence_town_available_idx
  on public.driver_presence (town, is_available, last_seen_at);
create index if not exists rides_rider_created_idx on public.rides (rider_id, created_at desc);
create index if not exists rides_driver_status_idx on public.rides (driver_id, status);

-- RLS: activar para todas las tablas; las políticas siguientes son un punto de partida.
alter table public.profiles enable row level security;
alter table public.driver_presence enable row level security;
alter table public.rides enable row level security;
alter table public.driver_announcements enable row level security;
alter table public.device_tokens enable row level security;

create policy "profiles read own" on public.profiles
  for select to authenticated using (id = auth.uid());
create policy "profiles update own limited" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "rider reads own rides" on public.rides
  for select to authenticated using (rider_id = auth.uid() or driver_id = auth.uid());
create policy "rider creates own ride" on public.rides
  for insert to authenticated with check (rider_id = auth.uid());

create policy "driver reads own presence" on public.driver_presence
  for select to authenticated using (driver_id = auth.uid());
create policy "driver updates own presence" on public.driver_presence
  for insert to authenticated with check (driver_id = auth.uid());
create policy "driver updates presence own" on public.driver_presence
  for update to authenticated using (driver_id = auth.uid()) with check (driver_id = auth.uid());

create policy "read own announcement" on public.driver_announcements
  for select to authenticated using (driver_id = auth.uid());
create policy "manage own announcement" on public.driver_announcements
  for all to authenticated using (driver_id = auth.uid()) with check (driver_id = auth.uid());

create policy "manage own device tokens" on public.device_tokens
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- NOTA DE SEGURIDAD:
-- Estas políticas no bastan para una operación real. En particular, la app no debe poder
-- autoasignarse el rol admin, marcarse como conductor verificado, modificar su suscripción,
-- aceptar viajes de otros ni leer ubicaciones ajenas. Añadir triggers/funciones seguras y
-- políticas más estrictas antes de exponer el backend. Mantener secretos en el servidor.
