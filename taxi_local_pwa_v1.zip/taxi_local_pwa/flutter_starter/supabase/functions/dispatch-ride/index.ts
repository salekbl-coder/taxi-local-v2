// Ejemplo ilustrativo de Supabase Edge Function.
// No desplegar en producción sin autenticación, validación de rol, rate limits,
// manejo de concurrencia y una integración real con Firebase Cloud Messaging.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return Response.json({ error: "Server configuration missing" }, { status: 500 });

  // IMPORTANTE: service role solo en servidor. Antes de producción hay que validar
  // el JWT del usuario y confirmar que ride_id pertenece al usuario autenticado.
  const supabase = createClient(url, serviceKey);
  const body = await req.json().catch(() => ({}));
  const rideId = body.ride_id as string | undefined;
  if (!rideId) return Response.json({ error: "ride_id is required" }, { status: 400 });

  const { data: ride, error: rideError } = await supabase
    .from("rides")
    .select("id,town,pickup_lat,pickup_lng,status")
    .eq("id", rideId)
    .single();

  if (rideError || !ride) return Response.json({ error: "Ride not found" }, { status: 404 });
  if (ride.status !== "pending") return Response.json({ error: "Ride is not pending" }, { status: 409 });
  if (ride.pickup_lat == null || ride.pickup_lng == null) {
    return Response.json({ error: "GPS coordinates required for automatic nearest-driver matching" }, { status: 422 });
  }

  // Haversine en servidor. Para un MVP con pocos conductores basta; a escala,
  // usar PostGIS/geography y una operación transaccional para evitar doble asignación.
  const { data: drivers, error: driversError } = await supabase
    .from("driver_presence")
    .select("driver_id,latitude,longitude,last_location_at,last_seen_at")
    .eq("town", ride.town)
    .eq("is_available", true)
    .not("latitude", "is", null)
    .not("longitude", "is", null)
    .gte("last_seen_at", new Date(Date.now() - 3 * 60 * 1000).toISOString());

  if (driversError) return Response.json({ error: "Could not search drivers" }, { status: 500 });

  const rad = (d: number) => d * Math.PI / 180;
  const km = (aLat: number, aLng: number, bLat: number, bLng: number) => {
    const dLat = rad(bLat - aLat), dLng = rad(bLng - aLng);
    const h = Math.sin(dLat/2)**2 + Math.cos(rad(aLat))*Math.cos(rad(bLat))*Math.sin(dLng/2)**2;
    return 6371 * 2 * Math.asin(Math.sqrt(h));
  };

  const nearest = (drivers ?? [])
    .filter(d => d.latitude != null && d.longitude != null)
    .map(d => ({ driver_id: d.driver_id, distance_km: km(ride.pickup_lat, ride.pickup_lng, d.latitude!, d.longitude!) }))
    .sort((a,b) => a.distance_km - b.distance_km)[0];

  if (!nearest) {
    await supabase.from("rides").update({ status: "no_driver", updated_at: new Date().toISOString() }).eq("id", rideId);
    return Response.json({ status: "no_driver" }, { status: 200 });
  }

  // Actualización condicional: solo se asigna si sigue pendiente.
  // En producción es preferible una RPC SQL transaccional que reserve al conductor
  // y gestione expiración/rehuso antes de probar con el siguiente conductor.
  const { data: updated, error: updateError } = await supabase
    .from("rides")
    .update({ driver_id: nearest.driver_id, status: "offered", offered_at: new Date().toISOString(), updated_at: new Date().toISOString() })
    .eq("id", rideId)
    .eq("status", "pending")
    .select("id,driver_id,status")
    .maybeSingle();

  if (updateError) return Response.json({ error: "Could not assign ride" }, { status: 500 });
  if (!updated) return Response.json({ error: "Ride was already handled" }, { status: 409 });

  // TODO: mandar push al token del conductor con Firebase Cloud Messaging.
  // TODO: esperar aceptación durante un intervalo breve; si expira, probar el siguiente.
  return Response.json({ status: "offered", driver_id: updated.driver_id, distance_km: Number(nearest.distance_km.toFixed(2)) });
});
