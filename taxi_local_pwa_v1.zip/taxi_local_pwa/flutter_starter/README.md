# Taxi Local v2 — Flutter + Supabase starter

Starter de arquitectura para una aplicación de taxis Android/iPhone. Incluye:
- Una app Flutter básica con modo cliente y modo conductor de demostración.
- Esquema SQL inicial para perfiles, ubicación de conductores, viajes, agenda y periodo de prueba.
- Una Edge Function TypeScript de ejemplo para localizar y notificar al conductor disponible más cercano.
- Una lista de tareas de seguridad y publicación.

## Importante
Este repositorio es una base de desarrollo, no una aplicación lista para transportar pasajeros reales. La pantalla Flutter todavía usa datos de demostración: no está conectada a Supabase ni recoge GPS real. La función de asignación y el SQL deben revisarse, desplegarse y probarse con autenticación, políticas RLS, límites de frecuencia, gestión de errores y monitorización antes de usarse en producción.

## Arquitectura sugerida
- App móvil: Flutter (un código base para Android e iOS).
- Datos y autenticación: Supabase Auth + PostgreSQL + Realtime.
- Asignación: función de servidor; nunca confiar en la app para decidir quién recibe un viaje.
- Push: Firebase Cloud Messaging, con tokens almacenados por usuario/dispositivo.
- Suscripciones: validar primero las reglas actuales de Apple/Google para este modelo comercial. No integrar Stripe directamente en la app hasta decidir el flujo de pago permitido para cada tienda.

## Costes que no desaparecen
El desarrollo puede empezar con planes gratuitos, pero publicar en tiendas, mantener backend disponible, mapas, notificaciones y soporte pueden generar costes. Supabase Free puede pausar proyectos con poca actividad; no lo consideres garantía para una operación comercial continua.

## Variables que deben configurarse
Crea un proyecto Supabase y configura `SUPABASE_URL` y `SUPABASE_ANON_KEY` en la app al conectarla. Las claves de servicio y secretos solo van en el servidor/Edge Functions, nunca en la app móvil.

## Siguiente fase
1. Crear proyecto Supabase y ejecutar `supabase/schema.sql`.
2. Implementar inicio de sesión por teléfono/email y verificación de conductores.
3. Conectar la app a Supabase y reemplazar datos de demostración.
4. Integrar permisos GPS, ubicación en segundo plano del conductor con consentimiento explícito y controles de batería.
5. Completar la función de asignación y el envío push real.
6. Implementar el periodo de prueba y cobro mediante un flujo compatible con las políticas de las tiendas.
7. Añadir pruebas de concurrencia, privacidad/RGPD, términos, política de privacidad, registro de incidentes y recuperación de datos.
