# Taxi Local PWA — piloto Elda y Petrer

Primera implementación web instalable (PWA) para probar el flujo de solicitud y gestión de viajes.

## Funciona en esta versión
- Interfaz adaptable a móviles y escritorio.
- Instalable como aplicación web cuando se sirve por HTTPS.
- Cache básica offline mediante Service Worker.
- Solicitudes con localidad (Elda/Petrer), recogida, destino opcional, pasajeros, reserva, teléfono y notas.
- Geolocalización del navegador con permiso explícito.
- Panel de conductor: disponibilidad local, aceptar solicitud y marcar viaje completado.
- Historial y cancelación de solicitudes.
- Validación básica de formularios y persistencia en `localStorage`.

## Limitación crítica
Esta entrega es un **prototipo funcional local**, no un sistema de despacho multiusuario. Los datos se guardan en el navegador del dispositivo. Una solicitud creada en el móvil del cliente NO aparecerá en el móvil del conductor. El GPS y la reserva son capturados en el formulario, pero no hay asignación remota, notificaciones push, autenticación ni backend conectado. No debe usarse para operar viajes reales con pasajeros.

## Probar localmente
Desde esta carpeta, inicia un servidor HTTP; no abras `index.html` directamente porque el service worker requiere HTTP/HTTPS:

```bash
python3 -m http.server 8080
```

Abre `http://localhost:8080`. Para probar desde otro teléfono de la misma red, sirve el proyecto en una dirección accesible; la instalación PWA y el GPS normalmente requieren HTTPS (excepto localhost).

### Prueba manual sugerida
1. Abre “Pedir un taxi”, rellena los campos obligatorios y envía.
2. Entra en “Mis viajes” y comprueba que aparece la referencia.
3. Ve a “Soy conductor”, activa disponibilidad y acepta la solicitud.
4. Márcala como completada y verifica el contador.
5. Crea una solicitud nueva y cancélala desde “Mis viajes”.
6. Prueba errores de formulario y permiso GPS denegado.

## Para convertirla en piloto multi-dispositivo
1. Crear/configurar proyecto Supabase (URL y clave pública; nunca poner la clave `service_role` en el navegador).
2. Añadir autenticación y perfiles separados de cliente y conductor.
3. Aplicar políticas RLS por usuario/rol y limitar acceso a teléfonos y ubicaciones.
4. Insertar solicitudes en PostgreSQL y escuchar cambios con Realtime.
5. Implementar asignación transaccional del conductor en servidor; evitar que dos conductores acepten el mismo viaje.
6. Añadir notificaciones, auditoría, eliminación/retención de datos y pruebas de seguridad.
7. Publicar por HTTPS y revisar privacidad/RGPD, términos y requisitos de transporte local.

No se han configurado credenciales ni se ha desplegado un servicio externo en esta entrega.
